package Model;

/**
 *
 * @author Klopp
 */
public class Delivery extends Products{
    private String DeliveryName;
    private String Product;
    private int DeliveryDistance;
    int Nothing = 0;

    public Delivery(String DeliveryName, String Product, int DeliveryDistance, String ProductName, int ProductPrice, int ProductID, String PeoductDescription) {
        super(ProductName, ProductPrice, ProductID, PeoductDescription);
        this.DeliveryName = DeliveryName;
        this.Product = Product;
        this.DeliveryDistance = DeliveryDistance;
    }

    public Delivery(String ProductName, int ProductPrice, int ProductID, String PeoductDescription) {
        super(ProductName, ProductPrice, ProductID, PeoductDescription);
    }

    public String getDeliveryName() {
        return DeliveryName;
    }

    public void setDeliveryName(String DeliveryName) {
        this.DeliveryName = DeliveryName;
    }

    public String getProduct() {
        return Product;
    }

    public void setProduct(String Product) {
        this.Product = Product;
    }

    public int getDeliveryDistance() {
        return DeliveryDistance;
    }

    public void setDeliveryDistance(int DeliveryDistance) {
        this.DeliveryDistance = DeliveryDistance;
    }

    @Override
    public String toString() {
        Products MyPoducts = new Products(Product, DeliveryDistance, DeliveryDistance, Product);
        return "DeliveryName: " + DeliveryName + "\t" + "Product: " + Product + "DeliveryDistance: " + DeliveryDistance;
    }
    
    
    

    
    
    
}
