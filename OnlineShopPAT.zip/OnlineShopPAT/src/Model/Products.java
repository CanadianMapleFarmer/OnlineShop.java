package Model;

/**
 *
 * @author Klopp
 */
public class Products {
    private String ProductName;
    private int ProductPrice;
    private int ProductID;
    private String PeoductDescription;

    public Products(String ProductName, int ProductPrice, int ProductID, String PeoductDescription) {
        this.ProductName = ProductName;
        this.ProductPrice = ProductPrice;
        this.ProductID = ProductID;
        this.PeoductDescription = PeoductDescription;
    }

    public String getPeoductDescription() {
        return PeoductDescription;
    }

    public void setPeoductDescription(String PeoductDescription) {
        this.PeoductDescription = PeoductDescription;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String ProductName) {
        this.ProductName = ProductName;
    }

    public int getProductPrice() {
        return ProductPrice;
    }

    public void setProductPrice(int ProductPrice) {
        this.ProductPrice = ProductPrice;
    }

    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int ProductID) {
        this.ProductID = ProductID;
    }

    @Override
    public String toString() {
        return "Products{" + "ProductName=" + ProductName + ", ProductPrice=" + ProductPrice + ", ProductID=" + ProductID + ", PeoductDescription=" + PeoductDescription + '}';
    }
    
    
}
