package Controller;

import java.io.FileNotFoundException;
import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Klopp
 */
public class Shopping {
    
    
    public void ProductScanner() {
        try {
            int ProductID;
            String ProductName;
            int ProductPrice;
            
            File Products = new File("Product list.txt");
            
            try (Scanner ProductScanner = new Scanner(Products)) {
                while (ProductScanner.hasNextLine()) {
                    ProductScanner.useDelimiter("#");
                    ProductID = ProductScanner.nextInt();
                    ProductName = ProductScanner.next();
                    ProductPrice = ProductScanner.nextInt();
                    
                    
                    System.out.println("ProductID = " + ProductID + " " + "PrductName = " + ProductName + " " + "ProductPrice = " + ProductPrice);
                }
            }
            
        } catch (FileNotFoundException e) {
            System.out.println("File not found!!!");
        }
    }

    

    
    
    
}
