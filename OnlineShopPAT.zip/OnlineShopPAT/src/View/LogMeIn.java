package View;

import javax.swing.*;

public class LogMeIn {

    
    public static void main(String[] args) {
        JFrame LogMeInFrame = new JFrame("LogMeIn");
        
        LogMeInFrame.setSize(600,400);
        LogMeInFrame.setLocationRelativeTo(null);
        LogMeInFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        LogMeInFrame.setVisible(true);
        
    }
    
}
